﻿namespace UnoOnline.Models
{
    public enum RequestStatus
    {
        Pending,
        Accepted,
        Rejected
    }
}