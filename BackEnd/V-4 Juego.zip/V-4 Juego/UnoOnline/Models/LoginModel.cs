﻿namespace UnoOnline.Models
{
    public class LoginModel
    {
        public string Identificador { get; set; }
        public string Password { get; set; }
    }
}
