﻿namespace UnoOnline.Models
{
    public enum StatusUser
    {
        Desconectado,
        Conectado,
        Jugando
    }
}