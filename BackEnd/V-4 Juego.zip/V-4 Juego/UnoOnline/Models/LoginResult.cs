﻿namespace UnoOnline.Models
{
    public class LoginResult
    {
        public string AccessToken { get; set; }
    }
}
