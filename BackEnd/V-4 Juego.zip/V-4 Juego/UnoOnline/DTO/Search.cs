﻿namespace UnoOnline.DTO
{
    public class Search
    {
        public string Apodo { get; set; } = "";
    }
}
